package com.udacity.catpoint.service;

import java.awt.*;

/**
 * Simple "service" for providing style information.
 */
public class StyleService {

    public static final Font HEADING_FONT = new Font("Sans Serif", Font.BOLD, 24);

}
