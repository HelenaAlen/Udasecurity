module com.udacity.catpoint.app {
    requires java.desktop;
    requires com.udacity.catpoint.security;
    requires com.udacity.catpoint.image;
    requires miglayout;
}